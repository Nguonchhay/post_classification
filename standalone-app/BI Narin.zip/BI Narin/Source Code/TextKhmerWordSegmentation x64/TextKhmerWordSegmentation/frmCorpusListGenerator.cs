﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using KhmerWordSegmentation;

namespace TextKhmerWordSegmentation
{
    public partial class frmCorpusListGenerator : Form
    {
        public frmCorpusListGenerator()
        {
            InitializeComponent();
        }

        public OpenFileDialog oPath;        

        private void btnStart_Click(object sender, EventArgs e)
        {
            System.IO.FileInfo fileInfo = new System.IO.FileInfo(oPath.FileName);
            if (fileInfo.Extension == ".txt")
            {
                try
                {
                    StringBuilder sText;
                    
                    List<string> mySegWordList = new List<string>();
                    SortedList<string, string> myWordList = new SortedList<string, string>();
                    SortedList<string, string[]> myWordListB = new SortedList<string, string[]>();
                    List<string> listIndex = new List<string>();
                    List<string> listIndex2 = new List<string>();
                    StringBuilder tString = new StringBuilder();
                    string tCode;
                    string tLine = "";

                    StreamReader objReader = new StreamReader(txtInputFile.Text);                    
                    while (tLine != null)
                    {
                        tLine = objReader.ReadLine();
                        if (tLine != null)
                        {
                            sText = new StringBuilder(tLine);
                            mySegWordList = KhWordSegment.semiWordSegmentSpell(sText);
                            for (int i = 0; i < mySegWordList.Count; i++)
                            {
                                tString = tString.Append(mySegWordList[i].Replace("\u17D2\u178F", "\u17D2\u178A"));                                
                            }
                            tCode = KhWordSegment.toAssciiCodeReverse(tString.ToString());

                            if(!myWordList.ContainsKey(tCode)){
                                myWordList.Add(tCode,tString.ToString());                                
                            }
                            tString.Length=0;

                        }
                    }
                    objReader.Close();

                    //myWordList.Sort();
                    listIndex = myWordList.Keys.ToList();
                    
                    string reverseKey;
                    //int count0=0;
                    //int count1=0;
                    //int count2=0;
                    //int count3=0;
                    for (int i = 0; i < listIndex.Count; i++)

                    {
                        string[] newString = new string[2];
                        reverseKey = KhWordSegment.toAssciiCode(myWordList[listIndex[i]]);
                        newString[0] = myWordList[listIndex[i]];

                        if (i + 1 == listIndex.Count)
                        {
                            newString[1] = "1";                            
                            myWordListB.Add(reverseKey, newString);
                            //tString.Append(listIndex[i]).Append("\t1");                            
                        }

                        else if (listIndex[i + 1].Trim().StartsWith(listIndex[i], StringComparison.Ordinal))
                        {
                            newString[1] = "0";
                            
                            //tString.Append(listIndex[i]).Append("\t0\n");
                            myWordListB.Add(reverseKey, newString);
                        }
                        else
                        {
                            newString[1] = "1";
                            
                            //tString.Append(listIndex[i]).Append("\t1\n");
                            myWordListB.Add(reverseKey, newString);
                        }
                    }


                    listIndex2 = myWordListB.Keys.ToList();
                    for(int i = 0; i < listIndex2.Count ; i++)
                    {
                        string[] newString = new string[2];
                        newString = myWordListB[listIndex2[i]];
                        if (i + 1 == listIndex2.Count)
                        {                            
                            int nValue = Convert.ToInt16(newString[1]) + 2;
                            tString.Append(newString[0]).Append("\t").Append(nValue);

                            //if (nValue == 2) count2++;
                            //else count3++;
                        }
                        else if (listIndex2[i + 1].Trim().StartsWith(listIndex2[i], StringComparison.Ordinal))
                        {                         
                            tString.Append(newString[0]).Append("\t").Append(newString[1]).Append("\r\n");
                            //if (Convert.ToInt16(newString[1]) == 0) count0++;
                            //else count1++;
                        }
                        else
                        {
                            int nValue = Convert.ToInt16(newString[1]) + 2;
                            tString.Append(newString[0]).Append("\t").Append(nValue).Append("\r\n");
                            //if (nValue == 2) count2++;
                            //else count3++;
                            
                        }

                    }


                    //MessageBox.Show("Count0:["+count0+"]-Count1:["+count1+"]-Count2:["+count2+"]-Count3:["+count3+"]");

                    StreamWriter objWriter = new StreamWriter(txtOutputFile.Text);
                    objWriter.WriteLine(tString);
                    objWriter.Close();

                    MessageBox.Show("Generate corpus list is done!");
                    
                }
                catch (Exception j)
                {
                    MessageBox.Show(j.Message);
                }
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            // Create an OpenFileDialog object.
            oPath = new OpenFileDialog();
            //Initialize the filter to look for text files.
            oPath.Filter = "Text Files(*.txt)|*.txt";

            if (oPath.ShowDialog() == DialogResult.OK)
            {
                txtInputFile.Text = oPath.FileName;
                txtOutputFile.Text = Path.GetDirectoryName(oPath.FileName)
                    + "\\"
                    + Path.GetFileNameWithoutExtension(oPath.FileName)
                    + "(WordList)"
                    + Path.GetExtension(oPath.FileName);
            }
        }
    }
}
