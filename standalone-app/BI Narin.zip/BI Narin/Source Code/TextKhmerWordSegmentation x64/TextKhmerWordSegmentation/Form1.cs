﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using KhmerWordSegmentation;

namespace TextKhmerWordSegmentation
{
    public partial class Form1 : Form
    {
        //KhWordSegment khWordSegment = new KhWordSegment();
        public Form1()
        {
            InitializeComponent();
        }

        public OpenFileDialog oPath;
        
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            // Create an OpenFileDialog object.
            oPath = new OpenFileDialog();            
            //Initialize the filter to look for text files.
            oPath.Filter = "Text Files(*.txt)|*.txt|Docs Files (*.docx)|*.docx";
            
            if (oPath.ShowDialog() == DialogResult.OK)
            {                
                txtInputFile.Text = oPath.FileName;
                txtOutputFile.Text = Path.GetDirectoryName(oPath.FileName) 
                    + "\\" 
                    + Path.GetFileNameWithoutExtension(oPath.FileName) 
                    + "(wrapped)"
                    + Path.GetExtension(oPath.FileName);                
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            System.IO.FileInfo fileInfo = new System.IO.FileInfo(oPath.FileName);
            
            if ((fileInfo.Extension == ".docx") || (fileInfo.Extension == ".doc"))
            {
                try
                {
                    KhWordSegment khWordSegment = new KhWordSegment();
                    khWordSegment.WordSegmentOpenXMLDoc(txtInputFile.Text, txtOutputFile.Text, "\u200B",0);
                }
                catch (Exception j)
                {
                    MessageBox.Show(j.Message);
                }
            }
            else
            {
                try
                {
                    KhWordSegment khWordSegment = new KhWordSegment();
                    khWordSegment.WordSegmentPlainText(txtInputFile.Text, txtOutputFile.Text, "\u200B", 0);
                }
                catch (Exception j)
                {
                    MessageBox.Show(j.Message);
                }
                
            }

            sw.Stop();
            TimeSpan elapsedTime = sw.Elapsed;
            MessageBox.Show("Text Word Segmentation (FMM) is Completed!" + "(Speed:" + elapsedTime.Duration().ToString() + ")");
        }

        private void btnSaveTo_Click(object sender, EventArgs e)
        {
            // Create an OpenFileDialog object.
            SaveFileDialog sPath = new SaveFileDialog();                        
            //Initialize the filter to look for text files.
            sPath.Filter = "Text Files(*.txt)|*.txt|Docs Files (*.docx)|*.docx";
            if (sPath.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {                
                txtOutputFile.Text = sPath.FileName;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            System.IO.FileInfo fileInfo = new System.IO.FileInfo(oPath.FileName);
            if ((fileInfo.Extension == ".docx") || (fileInfo.Extension == ".doc"))
            {
                try
                {
                    KhWordSegment khWordSegment = new KhWordSegment();
                    khWordSegment.WordSegmentOpenXMLDoc(txtInputFile.Text, txtOutputFile.Text, "\u200B", 1);
                }
                catch (Exception j)
                {
                    MessageBox.Show(j.Message);
                }
            }
            else
            {
                try
                {
                    KhWordSegment khWordSegment = new KhWordSegment();
                    khWordSegment.WordSegmentPlainText(txtInputFile.Text, txtOutputFile.Text, "\u200B", 1);
                }
                catch (Exception j)
                {
                    MessageBox.Show(j.Message);
                }

            }

            sw.Stop();
            TimeSpan elapsedTime = sw.Elapsed;
            MessageBox.Show("Text Word Segmentation (BMM) is Completed!" + "(Speed:" + elapsedTime.Duration().ToString() + ")");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            System.IO.FileInfo fileInfo = new System.IO.FileInfo(oPath.FileName);
            if ((fileInfo.Extension == ".docx") || (fileInfo.Extension == ".doc"))
            {
                try
                {
                    KhWordSegment khWordSegment = new KhWordSegment();
                    khWordSegment.WordSegmentOpenXMLDoc(txtInputFile.Text, txtOutputFile.Text, "\u200B", 2);
                }
                catch (Exception j)
                {
                    MessageBox.Show(j.Message);
                }
            }
            else
            {
                try
                {
                    KhWordSegment khWordSegment = new KhWordSegment();
                    khWordSegment.WordSegmentPlainText(txtInputFile.Text, txtOutputFile.Text, "\u200B", 2);
                }
                catch (Exception j)
                {
                    MessageBox.Show(j.Message);
                }

            }

            sw.Stop();
            TimeSpan elapsedTime = sw.Elapsed;
            MessageBox.Show("Text Word Segmentation (BiMM) is Completed!" + "(Speed:" + elapsedTime.Duration().ToString() + ")");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmCorpusListGenerator frmCLG = new frmCorpusListGenerator();
            frmCLG.Show();
        }


    }
}
