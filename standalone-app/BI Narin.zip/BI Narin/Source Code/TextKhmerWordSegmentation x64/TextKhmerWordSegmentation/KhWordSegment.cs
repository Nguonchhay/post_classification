﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;

using System.Xml;
using System.Xml.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Windows.Forms;
using OpenXmlPowerTools;



namespace KhmerWordSegmentation
{
    class KhWordSegment
    {
        private static List<string> mySemiSegWord;
        private static Dictionary<string, int> myDicDicHash = new Dictionary<string, int>(StringComparer.Ordinal);        
        private string path = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), @"DicList\WordList.txt");

        private static string exceptChar = "\t\r\n\"!#$%&'()*+,-./:;<=>?@[\\]{}|~€…‰“”˜™£§©«®»¥។៕៖ៗ៛ ០១២៣៤៥៦៧៨៩0123456789 ";
        private static char[] myException = exceptChar.ToCharArray();
        private static List<int> segIndex = new List<int>();
        private static List<int> splitPos = new List<int>();

        /***********************************************************************************

            Initial
         
        ***********************************************************************************/
        /// <summary>
        /// Constructor
        /// </summary>
        public KhWordSegment()
        {
            myDicDicHash = khReadTextFileDic(path);            
        }

        /// <summary>
        /// Load all words in dictionary file to Hashtable for comparision          
        /// </summary>
        public Hashtable khReadTextFileHash(String filepath)
        {
            StreamReader objReader = new StreamReader(filepath);
            string sLine = "";
            Hashtable arrText = new Hashtable();
            int numIndex = 0;
            while (sLine != null)
            {
                sLine = objReader.ReadLine();
                if (sLine != null)
                {
                    numIndex = numIndex + 1;
                    arrText.Add(sLine,numIndex);
                }
            }
            objReader.Close();
            return arrText;
        }

        /// <summary>
        /// Load all words in dictionary file to Dictionary for comparision
        /// </summary>
        public Dictionary<string,int> khReadTextFileDic(String filepath)
        {
            StreamReader objReader = new StreamReader(filepath);
            string[] sLine;
            string tLine = "";
            Dictionary<string, int> arrText = new Dictionary<string, int>();            
            //int numIndex = 0;
            while (tLine != null)
            {
                tLine = objReader.ReadLine();
                if (tLine != null)
                {
                    sLine = tLine.Split('\t');
                    if (sLine.Length == 1)
                    {
                        arrText.Add(sLine[0], 0);
                    }
                    else
                    {
                        arrText.Add(sLine[0], Convert.ToInt32(sLine[1]));
                    }
                }
            }
            objReader.Close();
            return arrText;
        }
                
        /***********************************************************************************

            Semi-Word Segmentation 
         
        ***********************************************************************************/
        /// <summary>
        /// Semi Word Segmentation into syllables
        /// </summary>
        /// <param name="text2Cut">Unsegment Text</param>
        /// <returns>List of segmented syllables</returns>
        public static List<string> semiWordSegment(string text2Cut)
        {
            string myword = "";
            //char[] myChar = text2Cut.Trim().ToCharArray();
            char[] myChar = text2Cut.ToCharArray();
            List<string> mySemiWordSeg = new List<string>();

            for (int i = 0; i < myChar.Length; i++)
            {
                myword = myword + myChar[i];
                if (i + 1 < myChar.Length)
                {
                    if (myChar[i + 1] >= '\u1780' && myChar[i + 1] <= '\u17A2' && myChar[i] != '\u17D2')
                    {
                        //myword = myword.Trim();
                        mySemiWordSeg.Add(myword);
                        myword = "";
                    }

                    //Independant Vowels
                    else if (myChar[i + 1] >= '\u17A5' && myChar[i + 1] <= '\u17B3')
                    {
                        //myword = myword.Trim();
                        mySemiWordSeg.Add(myword);
                        myword = "";
                    }
                    else if (myChar[i + 1] >= '\u17D4' && myChar[i + 1] <= '\u17D7')
                    {
                        //myword = myword.Trim();
                        mySemiWordSeg.Add(myword);
                        myword = "";
                    }
                    // khmer number
                    else if ((myChar[i + 1] >= '\u17E0' && myChar[i + 1] <= '\u17E9'))
                    {
                        if (!(myChar[i] >= '\u17E0' && myChar[i] <= '\u17E9') && !(myChar[i] == '\u002C' || myChar[i] == '\u002E'))
                        {
                            //myword = myword.Trim();
                            mySemiWordSeg.Add(myword);
                            myword = "";
                        }

                    }

                    //,. in khmer number
                    else if (myChar[i + 1] == '\u002C' || myChar[i + 1] == '\u002E')
                    {
                        if ((myChar[i] >= '\u1780' && myChar[i] <= '\u17DD') || (myChar[i] >= '\u17F0' && myChar[i] <= '\u17F9'))
                        {
                            //myword = myword.Trim();
                            mySemiWordSeg.Add(myword);
                            myword = "";
                        }

                    }
                    
                    // Not Range in Khmer Unicode characters
                    else if (!(myChar[i + 1] >= '\u1780' && myChar[i + 1] <= '\u17F9'))
                    {
                        if ((myChar[i] >= '\u1780' && myChar[i] <= '\u17F9'))
                        {
                            //myword = myword.Trim();
                            mySemiWordSeg.Add(myword);
                            myword = "";
                        }
                    }                    
                }

            }
            //myword = myword.Trim();
            mySemiWordSeg.Add(myword);

            return mySemiWordSeg;
        }

        /// <summary>
        /// Semi Word Segmentation into syllables based on Khmer Word Spelling Order (StringBuilder)
        /// </summary>
        /// <param name="text2Cut">Unsegment Text</param>
        /// <returns>List of segmented syllables</returns>
        public static List<string> semiWordSegmentSpell(StringBuilder myChar)
        {
            StringBuilder myWord = new StringBuilder();
            List<string> mySemiWordSeg = new List<string>();
            int hConsonant = 0; //consonant 
            int hRobat = 0;
            int hConsonantShifter = 0;
            int hSubscript = 0;
            int hVowel = 0;
            int hVariousSign = 0;
            bool isSemiWord = false;

            if (myChar[0] >= '\u1780' && myChar[0] <= '\u17A2') hConsonant = 1;

            for (int i = 0; i < myChar.Length; i++)
            {
                myWord.Append(myChar[i]);
                if (i + 1 < myChar.Length)
                {
                    if (hConsonant == 1)
                    {
                        //Robat
                        if (myChar[i + 1] == '\u17CC')
                        {
                            if (!(myChar[i] >= '\u1780' && myChar[i] <= '\u17A2'))
                            {
                                isSemiWord = true;
                            }
                            else
                            {
                                hRobat++;
                            }
                        }
                        //Consonant Shifter
                        else if (myChar[i + 1] == '\u17C9' || myChar[i + 1] == '\u17CA')
                        {
                            if (!(myChar[i] >= '\u1780' && myChar[i] <= '\u17A2'))
                            {
                                isSemiWord = true;
                            }
                            else
                            {
                                hConsonantShifter++;
                            }
                        }
                        //Subscript
                        else if (myChar[i + 1] >= '\u1780' && myChar[i + 1] <= '\u17A2' && myChar[i] == '\u17D2')
                        {
                            if ((
                                i > 1
                                && myChar[i + 1] == '\u179A'
                                && myChar[i - 1] == '\u179A'
                                && myChar[i - 2] == '\u17D2'
                                )                                
                                ||
                                (
                                i > 2
                                && myChar[i + 1] >= '\u1780' && myChar[i + 1] <= '\u17A2'
                                && myChar[i - 1] >= '\u1780' && myChar[i - 1] <= '\u17A2'
                                && myChar[i - 2] == '\u17D2'
                                && !(myChar[i - 3] >= '\u1780' && myChar[i - 3] <= '\u17A2')
                               ))
                            {
                                //myWord.Remove((myWord.Length - 1), 1);
                                myWord.Length -= 1;                                
                                mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                                myWord.Length = 0;
                                myWord.Append(myChar[i]);

                                hConsonant = 0; //consonant 
                                hRobat = 0;
                                hConsonantShifter = 0;
                                hSubscript = 0;
                                hVowel = 0;
                                hVariousSign = 0;
                                continue;
                            }
                            else
                            {
                                hSubscript++;
                            }
                        }
                        // Vowels
                        else if (myChar[i + 1] >= '\u17B6' && myChar[i + 1] <= '\u17C5')
                        {
                            
                            if ((myChar[i] >= '\u17B6' && myChar[i] <= '\u17C5') &&
                                !(myChar[i]=='\u17BE' && myChar[i + 1] == '\u17B6') 
                               )
                            {
                                isSemiWord = true;
                            }
                            else if ((myChar[i + 1] != '\u17B6' && myChar[i + 1] != '\u17BF' &&
                                myChar[i + 1] != '\u17C0' && myChar[i + 1] != '\u17C4' && myChar[i + 1] != '\u17C5')
                                && (myChar[i] == '\u17C6' || (myChar[i] >= '\u17CB' && myChar[i] <= '\u17D1'))
                                )
                            {
                                isSemiWord = true;
                            }
                            else
                            {
                                hVowel++;
                            }
                        }
                        // Various Sign
                        else if (myChar[i + 1] == '\u17C6' || (myChar[i + 1] >= '\u17CB' && myChar[i + 1] <= '\u17D1'))
                        {
                            hVariousSign++;
                        }

                        if (isSemiWord == true || hRobat > 1 || hConsonantShifter > 1 || hSubscript > 2 || hVowel > 2)
                        {
                            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                            myWord.Length = 0;
                            hConsonant = 0; //consonant 
                            hRobat = 0;
                            hConsonantShifter = 0;
                            hSubscript = 0;
                            hVowel = 0;
                            hVariousSign = 0;
                            isSemiWord = false;
                            continue;
                        }
                    }

                    // Consonants
                    if (myChar[i + 1] >= '\u1780' && myChar[i + 1] <= '\u17A2' && myChar[i] != '\u17D2')
                    {
                        mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                        myWord.Length = 0;
                        hConsonant = 1;
                        hRobat = 0;
                        hConsonantShifter = 0;
                        hSubscript = 0;
                        hVowel = 0;
                        hVariousSign = 0;                        
                    }

                    //Independant Vowels
                    else if (myChar[i + 1] >= '\u17A5' && myChar[i + 1] <= '\u17B3')
                    {
                        mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                        myWord.Length = 0;
                    }
                    
                    // khmer number
                    else if ((myChar[i + 1] >= '\u17E0' && myChar[i + 1] <= '\u17E9'))
                    {
                        if (!(myChar[i] >= '\u17E0' && myChar[i] <= '\u17E9') && !(myChar[i] == '\u002C' || myChar[i] == '\u002E'))
                        {
                            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                            myWord.Length = 0;
                        }
                    }

                    //,. between khmer number
                    else if (myChar[i + 1] == '\u002C' || myChar[i + 1] == '\u002E')
                    {
                        if ((myChar[i] >= '\u1780' && myChar[i] <= '\u17DD') ||
                            (myChar[i] >= '\u17F0' && myChar[i] <= '\u17F9')                            
                           )
                        {
                            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                            myWord.Length = 0;
                        }
                        else if ((i + 2) < myChar.Length)
                        {
                            if ((myChar[i + 2] >= '\u1780' && myChar[i + 2] <= '\u17DD') ||
                                (myChar[i + 2] >= '\u17F0' && myChar[i + 2] <= '\u17F9')
                               )
                            {
                                mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                                myWord.Length = 0;
                            }
                        }
                    }
                    //Other Khmer Sign
                    else if (myChar[i + 1] >= '\u17D4' && myChar[i + 1] <= '\u17DD')
                    {
                        if (!(myChar[i] >= '\u17D4' && myChar[i] <= '\u17DD'))
                        {
                            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                            myWord.Length = 0;
                        }
                    }
                    
                    //Other Khmer Symbol
                    else if (myChar[i + 1] >= '\u17F0' && myChar[i + 1] <= '\u17F9')
                    {
                        if (!(myChar[i] >= '\u17F0' && myChar[i] <= '\u17F9'))
                        {
                            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                            myWord.Length = 0;
                        }
                    } 
                    //Space
                    else if (myChar[i + 1] == '\u0020' && myChar[i] != '\u0020')
                    {                                                    
                            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                            myWord.Length = 0;                        
                    }
                    // Not Range in Khmer Unicode characters
                    else if (!(myChar[i + 1] >= '\u1780' && myChar[i + 1] <= '\u17F9'))
                    {
                        if ((myChar[i] >= '\u1780' && myChar[i] <= '\u17F9'))
                        {
                            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
                            myWord.Length = 0;
                        }
                    }
                }

            }                        
            mySemiWordSeg.Add(String.Intern(correctSpellOrder(myWord)));
            return mySemiWordSeg;
        }
        
        /// <summary>
        /// Correct Khmer Word Spelling Order
        /// </summary>
        /// <param name="str">String of Khmer syllable</param>
        /// <returns>String of Khmer syllable with correct order</returns>
        public static string correctSpellOrder(StringBuilder myChar)
        {            
            char temp;
            if (myChar.Length > 2 && myChar[0] >= '\u1780' && myChar[0] <= '\u17A2')
            {
                //Subscript
                if (myChar.Length > 3 && myChar[1] == '\u17D2' && myChar[2] >= '\u1780' && myChar[2] <= '\u17A2')
                {
                    // SSS,ESS,WSS <-> Consonant Shifter
                    if (myChar[3] == '\u17C9' || myChar[3] == '\u17CA')
                    {
                        temp = myChar[3];                        
                        myChar.Remove(3, 1);
                        myChar.Insert(1, temp);
                    }
                    // WSS <-> SSS,ESS
                    else if (myChar.Length > 4)
                    {
                        if (myChar[2] == '\u179A' &&
                            (myChar[4] >= '\u1780' && myChar[4] <= '\u1799') ||
                            (myChar[4] >= '\u179B' && myChar[4] <= '\u17A2')
                           )
                        {
                            temp = myChar[2];
                            myChar[2] = myChar[4];
                            myChar[4] = temp;
                        }
                    }
                }

                // Vowel
                else if (myChar.Length > 3 && myChar[1] >= '\u17B6' && myChar[1] <= '\u17C5')
                {
                    // WV,EV,NV,SV <-> WSS
                    if ((
                        (myChar[1] >= '\u17B6' && myChar[1] <= '\u17BD') || 
                        (myChar[1] >= '\u17C1' && myChar[1] <= '\u17C3')
                        ) &&
                        (myChar[3] == '\u179A' && myChar[2] == '\u17D2')
                        )
                    {
                        temp = myChar[1];
                        myChar.Remove(1, 1);
                        myChar.Insert(3, temp);
                    }

                    // WV,EV,NV <-> SSS
                    else if (
                        (
                        (myChar[1] >= '\u17B6' && myChar[1] <= '\u17BA') ||
                        (myChar[1] >= '\u17C1' && myChar[1] <= '\u17C3')
                        ) &&
                        (myChar[3] >= '\u1780' && myChar[3] <= '\u17A2' && myChar[2] == '\u17D2') &&
                        (myChar[3] != '\u179A' && myChar[3] != '\u1783' && myChar[3] != '\u1788' && myChar[3] != '\u178D' && myChar[3] != '\u1794' && myChar[3] != '\u1799' && myChar[3] != '\u179E' && myChar[3] != '\u179F')
                        )
                    {
                        temp = myChar[1];
                        myChar.Remove(1, 1);
                        myChar.Insert(3, temp);
                    }

                    // WV,NV <-> ESS
                    else if (
                        (
                        (myChar[1] >= '\u17B7' && myChar[1] <= '\u17BA') ||
                        (myChar[1] >= '\u17C1' && myChar[1] <= '\u17C3')
                        ) &&
                        (myChar[2] == '\u17D2') &&
                        (myChar[3] == '\u1783' && myChar[3] == '\u1788' && myChar[3] == '\u178D' && myChar[3] == '\u1794' && myChar[3] == '\u1799' && myChar[3] == '\u179E' && myChar[3] == '\u179F')
                        )
                    {
                        temp = myChar[1];
                        myChar.Remove(1, 1);
                        myChar.Insert(3, temp);
                    }  
                }

                // Verious Sign
                else if (myChar[1] == '\u17C6' || (myChar[1] >= '\u17CB' && myChar[1] <= '\u17D1'))
                {
                    // Verious Sign <-> SSS,ESS,WSS
                    if(myChar[2] == '\u17D2' && myChar[3] >= '\u1780' && myChar[3] <= '\u17A2')
                    {
                        temp = myChar[1];
                        myChar.Remove(1, 1);
                        myChar.Insert(3, temp);
                    }

                    // Verious Sign <-> EV, 2 part vowel (OO & AU)
                    else if (myChar[2] == '\u17B6' || myChar[2] == '\u17C4' || myChar[2] == '\u17C5')
                    {
                        temp = myChar[1];
                        myChar.Remove(1, 1);
                        myChar.Insert(2, temp);
                    }
                }

                //Special Case for WSS
                if (myChar.Length > 4)
                {                    
                    for (int i = 2; i < myChar.Length - 1; i++)
                    {
                        if (myChar[i] == '\u17D2' && myChar[i + 1] == '\u179A')
                        {
                            //Rotat & Consonant Shifter
                            if (myChar[1] == '\u17CC' || myChar[1] == '\u17C9' || myChar[1] == '\u17CA')
                            {
                                myChar.Remove(i, 2);
                                myChar.Insert(2, "\u17D2\u179A");
                                break;
                            }
                            //Subscript
                            else if (myChar[1] == '\u17D2' 
                                     && myChar[2] >= '\u1780' && myChar[2] <= '\u17A2'
                                     && myChar[2] != '\u179A'
                                    )
                            {
                                myChar.Remove(i, 2);
                                myChar.Insert(3, "\u17D2\u179A");
                                break;
                            }
                            else if ((myChar[1] >= '\u17B6' && myChar[1] <= '\u17C5') ||
                                    (myChar[1] == '\u17C6' || (myChar[1] >= '\u17CB' && myChar[1] <= '\u17D1'))
                                   )
                            {
                                myChar.Remove(i, 2);
                                myChar.Insert(1, "\u17D2\u179A");
                                break;
                            }
                        }
                    }
                }

            }
            return myChar.ToString();
        }


        /***********************************************************************************

            Word Segmentation 
         
        ***********************************************************************************/
        /// <summary>
        /// Get Segment Word
        /// </summary>
        /// <param name="start">Start index of segment word</param>
        /// <param name="end">End index of segment word</param>
        public static string getSegmentWord(int start, int end)
        {
            StringBuilder myWord = new StringBuilder();
            for (int index = start; index <= end; index++)
            {
                myWord.Append(mySemiSegWord[index]);
            }            
            return myWord.ToString();
                        
        }

        /// <summary>
        /// Convert Khmer characters to ASCII Code
        /// </summary>
        /// <param name="str">String of Khmer characters</param>
        /// <returns>String of Khmer word in ASCII Code</returns>
        public static string toAssciiCode(string str)
        {
            string myStr = str;
            char[] myChar = myStr.ToCharArray();
            StringBuilder myAsscii = new StringBuilder();

            for (int index = 0; index < myChar.Length; index++)
                if (index != 0 && myChar[index - 1] == '\u17D2' && myChar[index] == '\u178F')
                {
                    myAsscii.Append(Convert.ToInt32('\u178A'));
                }
                else
                {
                    myAsscii.Append(Convert.ToInt32(myChar[index]));
                }
            return myAsscii.ToString();
        }

        /// <summary>
        /// Convert Khmer characters to ASCII Code
        /// </summary>
        /// <param name="myChar">String of Khmer characters</param>
        /// <returns>String of Khmer characters in ASCII Code</returns>
        public static string toAssciiCodeSb(StringBuilder myChar)
        {
            StringBuilder myAsscii = new StringBuilder();
            for (int index = 0; index < myChar.Length; index++)
            {
                //subscript "TA" or "DA"
                if (index != 0 && myChar[index - 1] == '\u17D2' && myChar[index] == '\u178F')
                {
                    myAsscii.Append(Convert.ToInt32('\u178A'));
                }
                else
                {
                    myAsscii.Append(Convert.ToInt32(myChar[index]));
                }
            }
            return myAsscii.ToString();
        }

        /// <summary>
        /// Convert Khmer characters to Code
        /// </summary>
        /// <param name="myChar">String of Khmer characters</param>
        /// <returns>String of Khmer characters in Code</returns>
        public static string toAssciiCodeReverse(string str)
        {
            string myStr = str;
            char[] myChar = myStr.ToCharArray();
            StringBuilder myAsscii = new StringBuilder();            
            for (int index = myChar.Length-1; index >= 0; index--)
            {                
                    myAsscii.Append(Convert.ToInt32(myChar[index]));             
            }
            return myAsscii.ToString();
        }


        /// <summary>
        /// Convert Khmer characters to Code
        /// </summary>
        /// <param name="myChar">String of Khmer characters</param>
        /// <returns>String of Khmer characters in Code</returns>
        public static string toUCode(string str)
        {            
            //subscript "TA" or "DA"            
            return str.Replace("\u17D2\u178F", "\u17D2\u178A");
        }


        /// <summary>
        /// Word error detection (Using StringBuilder)
        /// </summary>
        /// <param name="start">Start index of word error</param>
        /// <param name="end">End index of word error</param>
        /// <returns></returns>
        public static int errorWordDetectionDicHash(int start, int end)
        {
            if (start == end) return 0;
            int numOfSemiIndex = 1;
            StringBuilder word2Compare = new StringBuilder();
            int myStart = start + 1;            
            while (myStart < end)
            {
                for (int index = myStart; index <= end; index++)
                {
                    word2Compare.Append(mySemiSegWord[index]);

                    
                    if (myDicDicHash.ContainsKey(toUCode(word2Compare.ToString())))                    
                    {
                        return numOfSemiIndex;
                    }
                }
                myStart = myStart + 1;
                numOfSemiIndex = numOfSemiIndex + 1;
                word2Compare.Length = 0;
            }
            return numOfSemiIndex;
        }

        /// <summary>
        /// Word error detection (Using StringBuilder)
        /// </summary>
        /// <param name="start">Start index of word error</param>
        /// <param name="end">End index of word error</param>
        /// <returns></returns>
        public static int errorWordDetectionDicHashBMM(int start, int end)
        {
            if (start == end) return 0;
            int numOfSemiIndex = 1;
            StringBuilder word2Compare = new StringBuilder();
            int myStart = end - 1;            
            while (myStart > start)
            {
                for (int index = myStart; index >= start; index--)
                {
                    word2Compare.Insert(0,mySemiSegWord[index]);

                    //if (myDicDicHash.ContainsKey(GetInt64HashCode(toUCode(word2Compare))))
                    if (myDicDicHash.ContainsKey(toUCode(word2Compare.ToString())))
                    //if (myDicDicHash.ContainsKey(toAssciiCodeSb(word2Compare)))                        
                    //if (myDicDicHash.ContainsKey(word2Compare.ToString()))
                    {
                        return numOfSemiIndex;
                    }
                }
                myStart = myStart - 1;
                numOfSemiIndex = numOfSemiIndex + 1;
                word2Compare.Length = 0;
            }
            return numOfSemiIndex;
        }

        /// <summary>
        /// Khmer Word Segmentation using Forward Maximum Matching & Dictionary Hashtable
        /// </summary>
        /// <param name="text2Cut">Unsegment Text</param>
        /// <returns>List of segmented words</returns>
        public static List<string> khWordSegFMMDicHash(StringBuilder text2Cut)
        {
            //List<string> mySegWords = new List<string>(); // store all segmented word that found in myDic
            mySemiSegWord = semiWordSegmentSpell(text2Cut);            
            return khWordSegFMMDicHash(0, mySemiSegWord.Count-1);
        }

        /// <summary>
        /// Khmer Word Segmentation using Forward Maximum Matching & Dictionary Hashtable
        /// </summary>        
        /// <param name="startIndex">Start index in Semi Segment Word</param>
        /// <param name="endIndex">End index in Semi segment Word</param>
        /// <returns>List of segmented words</returns>
        public static List<string> khWordSegFMMDicHash(int startIndex, int endIndex)
        {
            List<string> mySegWords = new List<string>(); // store all segmented word that found in myDic

            int foundindex = 0;
            int start = 0;
            int numOfJointSeg = 0;
            //string word2compare = "";
            StringBuilder word2compare = new StringBuilder();
            string foundWord = "";
            //Int64 uCode;
            string uCode;
            int cWord = 0;
            int startWrongWordIndex = 0;
            int countUnknown = 0;            
            int JointSegLimit = 12;
            bool checkWord = false;   
            int semiSegIndex = 0;
            char firstCharSegWord;

            //int fW = 0;
            //int uFW1 = 0;
            //int uFW2 = 0;
            //int sP = 0;

            for (start = startIndex; start <= endIndex; start++)
            {
                firstCharSegWord = Convert.ToChar(mySemiSegWord[start].Substring(0, 1));
                
                numOfJointSeg++;                
                word2compare.Append(mySemiSegWord[start]);
                
                if (numOfJointSeg <= JointSegLimit                        
                    && 
                    (
                        //Khmer Consonants
                        (firstCharSegWord >= '\u1780' && firstCharSegWord <= '\u17B3')
                        //Khmer Number
                        || (firstCharSegWord >= '\u17E0' && firstCharSegWord <= '\u17E9')
                        //Khmer Sign "KHAN","LEK TOO","KHMER CURRENCY"
                        || (firstCharSegWord == '\u17D4' || firstCharSegWord == '\u17D7' || firstCharSegWord == '\u17DB')
                        //Latin Number (0-9)
                        || (firstCharSegWord >= '\u0030' && firstCharSegWord <= '\u0039')
                        //Latin Capital Letter (A-Z)
                        || (firstCharSegWord >= '\u0041' && firstCharSegWord <= '\u005A')
                        //Latin Small letter (a-z)
                        || (firstCharSegWord >= '\u0061' && firstCharSegWord <= '\u007A') 
                    )
                   )
                {
                    //uCode = GetInt64HashCode(toUCode(word2compare));                    
                    uCode = toUCode(word2compare.ToString());                    
                    //uCode = toAssciiCodeSb(word2compare);                                        
                    if (myDicDicHash.ContainsKey(uCode))
                    //if (myDicDicHash.ContainsKey(word2compare.ToString()))
                    {
                        foundindex = start;
                        foundWord = word2compare.ToString();
                        cWord = myDicDicHash[uCode];
                    }
                    
                }
                else checkWord = true;

                if (start == endIndex || cWord == 2 || cWord == 3) checkWord = true;

                if (checkWord == true)
                {
                    if (foundWord != "")
                    {
                        start = foundindex;
                        foundindex = 0;                        
                        //saveSegmentWord(foundWord);
                        mySegWords.Add(String.Intern(foundWord));                        
                        foundWord = "";
                        //fW++;
                    }
                    else
                    {
                        
                        startWrongWordIndex = start - numOfJointSeg + 1;
                        if (startWrongWordIndex < start)
                        {                            
                            semiSegIndex=errorWordDetectionDicHash(startWrongWordIndex, start);
                            start = startWrongWordIndex + semiSegIndex -1;
                            mySegWords.Add(String.Intern(getSegmentWord(startWrongWordIndex, start)));
                            countUnknown = countUnknown + semiSegIndex;
                            //uFW1++;
                            //if (firstCharSegWord == ' ') sP++;
                        }
                        else
                        {
                            mySegWords.Add(String.Intern(word2compare.ToString()));
                            countUnknown = countUnknown + 1;
                            //uFW2++;
                        }
                        
                    }
                    word2compare.Length = 0;
                    numOfJointSeg = 0;
                    checkWord = false;
                    cWord = 0;
                }                
            }            
            mySegWords.Add(String.Intern(countUnknown.ToString()));
            //MessageBox.Show("Found Words:" + fW + " | Unknown Words(1):" + uFW1 + " | Unknown Words(2):" + uFW2 + " | Space:" + sP);
            return mySegWords;
        }


        /// <summary>
        /// Khmer Word Segmentation using Backward Maximum Matching & Dictionary Hashtable
        /// </summary>
        /// <param name="text2Cut">Unsegment Text</param>
        /// <returns>List of segmented words</returns>
        public static List<string> khWordSegBMMDicHash(StringBuilder text2Cut)
        {            
            mySemiSegWord = semiWordSegmentSpell(text2Cut);            
            return khWordSegBMMDicHash(0, mySemiSegWord.Count-1);
        }

        /// <summary>
        /// Khmer Word Segmentation using Backward Maximum Matching & Dictionary Hashtable
        /// </summary>
        /// <param name="startIndex">Start index in Semi Segment Word</param>
        /// <param name="endIndex">End index in Semi segment Word</param>
        /// <returns>List of segmented words</returns>
        public static List<string> khWordSegBMMDicHash(int startIndex, int endIndex)
        {
            List<string> mySegWords = new List<string>(); // store all segmented word that found in myDic

            int foundindex = 0;
            int start = 0;
            int numOfJointSeg = 0;
            //string word2compare = "";
            StringBuilder word2compare = new StringBuilder();
            string foundWord = "";
            //Int64 uCode;
            string uCode;
            int cWord = 0;
            int startWrongWordIndex = 0;
            int countUnknown = 0;
            int JointSegLimit = 12;
            bool checkWord = false;
            int semiSegIndex = 0;
            char firstCharSegWord;
            
            for (start = endIndex; start >= startIndex; start--)
            {
                firstCharSegWord = Convert.ToChar(mySemiSegWord[start].Substring(0, 1));

                numOfJointSeg++;
                word2compare.Insert(0,mySemiSegWord[start]);
                //word2compare.Append(mySemiSegWord[start], 0, mySemiSegWord[start].Length);
                if (numOfJointSeg <= JointSegLimit
                    &&
                    (
                    //Khmer Consonants
                        (firstCharSegWord >= '\u1780' && firstCharSegWord <= '\u17B3')
                    //Khmer Number
                        || (firstCharSegWord >= '\u17E0' && firstCharSegWord <= '\u17E9')
                    //Khmer Sign "KHAN","LEK TOO","KHMER CURRENCY"
                        || (firstCharSegWord == '\u17D4' || firstCharSegWord == '\u17D7' || firstCharSegWord == '\u17DB')
                    //Latin Number (0-9)
                        || (firstCharSegWord >= '\u0030' && firstCharSegWord <= '\u0039')
                    //Latin Capital Letter (A-Z)
                        || (firstCharSegWord >= '\u0041' && firstCharSegWord <= '\u005A')
                    //Latin Small letter (a-z)
                        || (firstCharSegWord >= '\u0061' && firstCharSegWord <= '\u007A')
                    )
                   )
                {
                    //uCode = GetInt64HashCode(toUCode(word2compare));                    
                    uCode = toUCode(word2compare.ToString());
                    //uCode = toAssciiCodeSb(word2compare);                                        
                    if (myDicDicHash.ContainsKey(uCode))
                    //if (myDicDicHash.ContainsKey(word2compare.ToString()))
                    {
                        foundindex = start;
                        foundWord = word2compare.ToString();
                        cWord = myDicDicHash[uCode];    
                    }
                    
                }
                else checkWord = true;

                if (start == startIndex || cWord == 1 || cWord == 3) checkWord = true;

                if (checkWord == true)
                {
                    if (foundWord != "")
                    {
                        start = foundindex;
                        foundindex = 0;                        
                        //mySegWords.Insert(0, String.Intern(foundWord));
                        mySegWords.Add(String.Intern(foundWord));
                        
                        foundWord = "";
                    }
                    else
                    {
                        
                        startWrongWordIndex = start + numOfJointSeg - 1;
                        if (startWrongWordIndex > start)
                        {                            
                            semiSegIndex = errorWordDetectionDicHashBMM(start, startWrongWordIndex);
                            start = startWrongWordIndex - semiSegIndex + 1;
                            //mySegWords.Insert(0, String.Intern(getSegmentWord(start, startWrongWordIndex)));
                            mySegWords.Add(String.Intern(getSegmentWord(start, startWrongWordIndex)));
                            countUnknown = countUnknown + semiSegIndex;
                        }
                        else
                        {                            
                            //mySegWords.Insert(0,String.Intern(word2compare.ToString()));
                            mySegWords.Add(String.Intern(word2compare.ToString()));
                            countUnknown = countUnknown + 1;
                        }
                    }
                    word2compare.Length = 0;
                    numOfJointSeg = 0;
                    checkWord = false;
                    cWord = 0;
                }
            }            
            mySegWords.Reverse();
            mySegWords.Add(String.Intern(countUnknown.ToString()));            
            return mySegWords;
        }

        /// <summary>
        /// Khmer Word Segmentation using Bidirectional Maximum Matching & Dictionary Hashtable
        /// </summary>
        /// <param name="text2Cut">Unsegment Text</param>
        /// <returns>List of segmented words</returns>
        public static List<string> khWordSegBiMMDicHash(StringBuilder text2Cut)
        {
            List<string> mySegWords = new List<string>(); // store final segmented words
            List<string> myFMMSegWords = new List<string>();
            List<string> myBMMSegWords = new List<string>();

            int semiStartIndex = 0;
            int semiEndIndex = 0;
            int countUnknown = 0;
            int countUnknownFMM = 0;
            int countUnknownBMM = 0;
            char firstCharSegWord;
            mySemiSegWord = semiWordSegmentSpell(text2Cut);

            for (int start = 0; start < mySemiSegWord.Count; start++)
            {
                // if the first character of Semi segment word
                firstCharSegWord = Convert.ToChar(mySemiSegWord[start].Substring(0, 1));

                if (start == (mySemiSegWord.Count - 1)
                    ||
                    !(
                    //Khmer Consonants
                    (firstCharSegWord >= '\u1780' && firstCharSegWord <= '\u17B3')
                    //Khmer Number
                    || (firstCharSegWord >= '\u17E0' && firstCharSegWord <= '\u17E9')
                    //Khmer Sign "KHAN","LEK TOO","KHMER CURRENCY"
                    || (firstCharSegWord == '\u17D4' || firstCharSegWord == '\u17D7' || firstCharSegWord == '\u17DB')
                    //Latin Number (0-9)
                    || (firstCharSegWord >= '\u0030' && firstCharSegWord <= '\u0039')
                    //Latin Capital Letter (A-Z)
                    || (firstCharSegWord >= '\u0041' && firstCharSegWord <= '\u005A')
                    //Latin Small letter (a-z)
                    || (firstCharSegWord >= '\u0061' && firstCharSegWord <= '\u007A')
                    ))
                {
                    if (start == (mySemiSegWord.Count - 1)) semiEndIndex = start;
                    else semiEndIndex = start - 1;

                    if (semiStartIndex < semiEndIndex)
                    {
                        myFMMSegWords = khWordSegFMMDicHash(semiStartIndex, semiEndIndex);
                        myBMMSegWords = khWordSegBMMDicHash(semiStartIndex, semiEndIndex);

                        countUnknownFMM = Convert.ToInt16(myFMMSegWords[myFMMSegWords.Count - 1]);
                        countUnknownBMM = Convert.ToInt16(myBMMSegWords[myBMMSegWords.Count - 1]);
                        myFMMSegWords.RemoveAt(myFMMSegWords.Count - 1);
                        myBMMSegWords.RemoveAt(myBMMSegWords.Count - 1);

                        if (countUnknownFMM + myFMMSegWords.Count > countUnknownBMM + myBMMSegWords.Count)
                        //if (countUnknownFMM > countUnknownBMM)
                        {
                            countUnknown = countUnknown + countUnknownBMM;
                            mySegWords.AddRange(myBMMSegWords);
                        }
                        else if (countUnknownFMM + myFMMSegWords.Count < countUnknownBMM + myBMMSegWords.Count)
                        //else if (countUnknownFMM < countUnknownBMM)
                        {
                            countUnknown = countUnknown + countUnknownFMM;
                            mySegWords.AddRange(myFMMSegWords);
                        }
                        else
                        {
                            if (myFMMSegWords.Count < myBMMSegWords.Count)
                            {
                                countUnknown = countUnknown + countUnknownFMM;
                                mySegWords.AddRange(myFMMSegWords);
                            }
                            else if (myFMMSegWords.Count > myBMMSegWords.Count)
                            {
                                countUnknown = countUnknown + countUnknownBMM;
                                mySegWords.AddRange(myBMMSegWords);
                            }
                            else
                            {
                                // Need a good algorithm to detect context sensitive content
                                countUnknown = countUnknown + countUnknownBMM;
                                mySegWords.AddRange(myBMMSegWords);
                            }
                        }
                        

                    }
                    else if (semiStartIndex == semiEndIndex)
                    {
                        mySegWords.Add(String.Intern(mySemiSegWord[semiEndIndex]));
                    }

                    if (start < (mySemiSegWord.Count - 1))
                    {
                        mySegWords.Add(String.Intern(mySemiSegWord[start]));
                        semiStartIndex = start + 1;
                    }



                }                
            }
            mySegWords.Add(String.Intern(countUnknown.ToString()));
            return mySegWords;
        }

        /***********************************************************************************

            Word Segmentation for Plain Text
         
        ***********************************************************************************/
        /// <summary>
        /// Process Word Segmentation of Plain Text
        /// </summary>
        /// <param name="sInputFile">Input path of unsegmented plain text file</param>
        /// <param name="sOutputFile">Output path of segmented plain text file</param>
        /// <param name="delimiter">Segment delimiter</param>
        public void WordSegmentPlainText(string sInputFile, string sOutputFile, string delimiter,int algorithm = 0)
        {
            StringBuilder sText = new StringBuilder();
            StreamReader objReader = new StreamReader(sInputFile);
            //string sText = objReader.ReadToEnd();
            sText.Append(objReader.ReadToEnd());
            objReader.Close();

            //string inputText = sText.Replace(delimiter, "");
            sText.Replace(delimiter, "");

            //string tString = "";
            StringBuilder tString = new StringBuilder();
            List<string> myListSeg = new List<string>();
            char firstCharSegWord;
            char firstCharSegWord2;
            if (sText.Length > 0)
            {                
                switch (algorithm)
                {
                    case 1:
                        myListSeg = khWordSegBMMDicHash(sText);
                        break;
                    case 2:
                        myListSeg = khWordSegBiMMDicHash(sText);
                        break;
                    default:
                        myListSeg = khWordSegFMMDicHash(sText);
                        break;
                }
                
                tString.Append(myListSeg[0]);
                for (int i = 1; i < myListSeg.Count - 1; i++)
                {
                    firstCharSegWord = Convert.ToChar(myListSeg[i].Substring(0, 1));
                    firstCharSegWord2 = Convert.ToChar(myListSeg[i - 1].Substring(0, 1));


                    if (!myException.Contains(firstCharSegWord) && !myException.Contains(firstCharSegWord2))
                    {
                        tString.Append(delimiter).Append(myListSeg[i]);
                    }
                    else
                    {
                        tString.Append(myListSeg[i]);
                    }
                    //tString.Append("\r\n").Append(myListSeg[i]);
                }
            }
            //return tString;
            StreamWriter objWriter = new StreamWriter(sOutputFile);
            objWriter.Write(tString);
            objWriter.Close();

        }


        /***********************************************************************************

            Word Segmentation for Word Document
         
        ***********************************************************************************/
        public static object WordSegmentTransform(XNode node, string delimiter, List<string> myListSeg, int depth, int algorithm = 0)
        {
            XElement element = node as XElement;
            if (element != null)
            {
                if (element.Name == W.p)
                {                    
                    StringBuilder contents = new StringBuilder(element
                        .LogicalChildrenContent(W.r)
                        .LogicalChildrenContent(W.t)
                        .Select(t => (string)t)
                        .StringConcatenate());

                    contents = contents.Replace(delimiter, "");


                    List<string> myListSeg1 = new List<string>();

                    if (contents.Length > 0)
                    {                        
                        switch (algorithm)
                        {
                            case 1:
                                myListSeg1 = khWordSegBMMDicHash(contents);
                                break;
                            case 2:
                                myListSeg1 = khWordSegBiMMDicHash(contents);
                                break;
                            default:
                                myListSeg1 = khWordSegFMMDicHash(contents);
                                break;
                        }                        
                        segIndex.Add(0);
                        splitPos.Add(0);
                        depth++;
                        segIndex[depth - 1] = 0;
                        splitPos[depth - 1] = myListSeg1[0].Length;
                    }

                    return new XElement(element.Name,
                        element.Attributes(),
                        element.Nodes().Select(n => WordSegmentTransform(n, delimiter, myListSeg1, depth,algorithm)));
                }


                else if (element.Name == W.r && element.Elements(W.t).Any())
                {
                    var collectionOfRuns = element.Elements()
                        .Where(e => e.Name != W.rPr)
                        .Select(e =>
                        {
                            if (e.Name == W.t)
                            {                                
                                string wT = "";
                                if ((string)e != delimiter)
                                {
                                    wT = (string)e;
                                    wT = wT.Replace(delimiter, "");
                                }
                                string tString = "";
                                if (wT != "")
                                {
                                    if (segIndex[depth - 1] < myListSeg.Count)
                                    {

                                        if (splitPos[depth - 1] >= wT.Length)
                                        {
                                            splitPos[depth - 1] = splitPos[depth - 1] - wT.Length;
                                            tString = wT;
                                        }
                                        else
                                        {

                                            char firstCharSegWord;
                                            char firstCharSegWord2;

                                            if (splitPos[depth - 1] == 0)
                                            {
                                                firstCharSegWord = Convert.ToChar(wT.Substring(splitPos[depth - 1], 1));
                                                firstCharSegWord2 = Convert.ToChar(myListSeg[segIndex[depth - 1]].Substring(myListSeg[segIndex[depth - 1]].Count() - 1, 1));

                                                if (!myException.Contains(firstCharSegWord) && !myException.Contains(firstCharSegWord2))                                                
                                                {
                                                    tString = delimiter;
                                                }
                                            }
                                            else
                                            {
                                                firstCharSegWord = Convert.ToChar(wT.Substring(splitPos[depth - 1], 1));
                                                firstCharSegWord2 = Convert.ToChar(wT.Substring(splitPos[depth - 1] - 1, 1));

                                                if (!myException.Contains(firstCharSegWord) && !myException.Contains(firstCharSegWord2))
                                                {
                                                    tString = wT.Substring(0, splitPos[depth - 1]) + delimiter;
                                                }
                                                else
                                                {
                                                    tString = wT.Substring(0, splitPos[depth - 1]);
                                                }
                                            }
                                        bb:
                                            segIndex[depth - 1]++;
                                            if (segIndex[depth - 1] >= (myListSeg.Count - 1)) goto cc;
                                            int segLenght = myListSeg[segIndex[depth - 1]].Length;


                                            if ((splitPos[depth - 1] + segLenght) >= wT.Length)
                                            {
                                                tString = tString + wT.Substring(splitPos[depth - 1]);
                                                splitPos[depth - 1] = (splitPos[depth - 1] + segLenght) - wT.Length;
                                            }
                                            else
                                            {
                                                firstCharSegWord = Convert.ToChar(wT.Substring((splitPos[depth - 1] + segLenght), 1));
                                                firstCharSegWord2 = Convert.ToChar(wT.Substring((splitPos[depth - 1] + segLenght - 1), 1));

                                                if (myListSeg[segIndex[depth - 1]].Trim() != "" && !myException.Contains(firstCharSegWord) && !myException.Contains(firstCharSegWord2))                                                
                                                {
                                                    tString = tString + wT.Substring(splitPos[depth - 1], segLenght) + delimiter;
                                                }
                                                else
                                                {
                                                    tString = tString + wT.Substring(splitPos[depth - 1], segLenght);
                                                }


                                                splitPos[depth - 1] = splitPos[depth - 1] + segLenght;
                                                goto bb;
                                            }
                                        }
                                    }
                                }

                            cc:

                                XAttribute xs = null;
                                if (tString != "")
                                {
                                    if (tString[0] == ' ' || tString[tString.Length - 1] == ' ')
                                    {
                                        xs = new XAttribute(XNamespace.Xml + "space", "preserve");
                                    }
                                }

                                //return new XElement(W.r, element.Elements(W.rPr), new XElement(W.t, e.Attributes(), tString));
                                return new XElement(W.r, element.Elements(W.rPr), new XElement(W.t, xs, tString));

                            }
                            else
                            {
                                XElement newRun = new XElement(W.r,
                                    element.Elements(W.rPr),
                                    e);
                                return newRun;
                            }
                        });
                    return collectionOfRuns;
                }

                else if (element.Name == W.txbxContent && element.Elements(W.p).Any())
                {
                    return new XElement(element.Name,
                        element.Attributes(),
                        element.Nodes().Select(n => WordSegmentTransform(n, delimiter, myListSeg, depth,algorithm)));
                }

                return new XElement(element.Name,
                    element.Attributes(),
                    element.Nodes().Select(n => WordSegmentTransform(n, delimiter, myListSeg, depth,algorithm)));
            }



            return node;

        }

        public static void WordSegmentInXDocument(XDocument xDocument, string delimiter, int algorithm = 0)
        {
            segIndex.Clear();
            splitPos.Clear();

            XElement newRoot = (XElement)WordSegmentTransform(xDocument.Root, delimiter, null, 0, algorithm);
            xDocument.Elements().First().ReplaceWith(newRoot);
        }

        public void WordSegmentOpenXMLDoc(string sInputFile, string sOutputFile, string delimiter, int algorithm = 0)
        {
            byte[] byteArray = File.ReadAllBytes(sInputFile);
            using (MemoryStream mem = new MemoryStream())
            {
                mem.Write(byteArray, 0, (int)byteArray.Length);

                using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(mem, true))
                {
                    //Word Segment
                    if (RevisionAccepter.HasTrackedRevisions(wordDoc))
                        throw new OpenXmlPowerToolsException(
                            "Word Segment will not work with documents " +
                            "that contain revision tracking.");
                    XDocument xDoc;
                    xDoc = wordDoc.MainDocumentPart.DocumentSettingsPart.GetXDocument();
                    if (xDoc.Descendants(W.trackRevisions).Any())
                        throw new OpenXmlPowerToolsException("Revision tracking is turned on for document.");


                    xDoc = wordDoc.MainDocumentPart.GetXDocument();
                    WordSegmentInXDocument(xDoc, delimiter, algorithm);
                    wordDoc.MainDocumentPart.PutXDocument();

                    foreach (var part in wordDoc.MainDocumentPart.HeaderParts)
                    {
                        xDoc = part.GetXDocument();
                        WordSegmentInXDocument(xDoc, delimiter, algorithm);
                        part.PutXDocument();
                    }
                    foreach (var part in wordDoc.MainDocumentPart.FooterParts)
                    {
                        xDoc = part.GetXDocument();
                        WordSegmentInXDocument(xDoc, delimiter, algorithm);
                        part.PutXDocument();
                    }
                    if (wordDoc.MainDocumentPart.EndnotesPart != null)
                    {
                        xDoc = wordDoc.MainDocumentPart.EndnotesPart.GetXDocument();
                        WordSegmentInXDocument(xDoc, delimiter, algorithm);
                        wordDoc.MainDocumentPart.EndnotesPart.PutXDocument();
                    }
                    if (wordDoc.MainDocumentPart.FootnotesPart != null)
                    {
                        xDoc = wordDoc.MainDocumentPart.FootnotesPart.GetXDocument();
                        WordSegmentInXDocument(xDoc, delimiter, algorithm);
                        wordDoc.MainDocumentPart.FootnotesPart.PutXDocument();
                    }

                    //Flush the contents of the package
                    //wordDoc.Package.Flush();             

                }

                using (FileStream fileStream = new FileStream(sOutputFile, FileMode.Create))
                {
                    mem.WriteTo(fileStream);
                }
            }

        }

    }
}
