﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms; 
using NetOffice;
using Word = NetOffice.WordApi;
using NetOffice.WordApi.Enums;
using Office = NetOffice.OfficeApi;
using NetOffice.OfficeApi.Enums;
using VBIDE = NetOffice.VBIDEApi;
using NetOffice.VBIDEApi.Enums;
using NetOffice.Tools;
using NetOffice.WordApi.Tools;

//using System.IO;
//using System.Xml.Linq;
//using OpenXmlPowerTools;
//using DocumentFormat.OpenXml;
//using DocumentFormat.OpenXml.Packaging;
//using DocumentFormat.OpenXml.Wordprocessing;

namespace KhmerWordSegmentation
{
    [COMAddin("KhmerWordSegmentation","Khmer Unicode Wrod Segmentation for Microsoft Word",3), CustomUI("KhmerWordSegmentation.RibbonUI.xml")]
    [GuidAttribute("AC02625A-3AEF-425C-BC72-620AE7CBEFCA"), ProgId("KhmerWordSegmentation.Addin")]
    public class Addin : COMAddin
    {        

        public Addin()
        {
            this.OnStartupComplete += new OnStartupCompleteEventHandler(Addin_OnStartupComplete);
            this.OnConnection += new OnConnectionEventHandler(Addin_OnConnection);
            this.OnDisconnection += new OnDisconnectionEventHandler(Addin_OnDisconnection);

        }

        #region IDTExtensibility2 Members

        void Addin_OnConnection(object Application, NetOffice.Tools.ext_ConnectMode ConnectMode, object AddInInst, ref Array custom)
        {   

        }

        void Addin_OnStartupComplete(ref Array custom)
        {

        }

        void Addin_OnDisconnection(NetOffice.Tools.ext_DisconnectMode RemoveMode, ref Array custom)
        {
           
        }

        #endregion		

		#region IRibbonExtensibility Members

        public void OnAction(Office.IRibbonControl control)
        {
            try
            {

                KhWordSegment khWordSegment = new KhWordSegment();
                string delimiter = "\u200B";
                switch (control.Id)
                {
                    case "btnWholeFMM":                        
                        khWordSegment.WordSegmentWhole(delimiter,0);
                        break;                    
                    case "btnWholeSecFMM":
                        khWordSegment.WordSegmentWholeHF(delimiter, 0);
                        break;
                    case "btnSelFMM":
                        khWordSegment.WordSegmentSelect(delimiter, 0);
                        break;
                    case "btnWholeBMM":
                        khWordSegment.WordSegmentWhole(delimiter, 1);
                        break;
                    case "btnWholeSecBMM":
                        khWordSegment.WordSegmentWholeHF(delimiter, 1);
                        break;
                    case "btnSelBMM":
                        khWordSegment.WordSegmentSelect(delimiter, 1);
                        break;
                    case "btnWholeBiMM":
                        khWordSegment.WordSegmentWhole(delimiter, 2);
                        break;
                    case "btnWholeSecBiMM":
                        khWordSegment.WordSegmentWholeHF(delimiter, 2);
                        break;
                    case "btnSelBiMM":
                        khWordSegment.WordSegmentSelect(delimiter, 2);
                        break;
                    default:
                        MessageBox.Show("Unkown Control Id: " + control.Id);
                        break;
                }
            }
            catch (Exception throwedException)
            {
                string details = string.Format("{1}{1}Details:{1}{1}{0}", throwedException.Message, Environment.NewLine);
                MessageBox.Show("An error occured in OnAction: " + details, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        
        
    }
}
